# Mutanabby AI — Crypto Signal System | سند معماری

> نسخه‌ی مکتوب تمام تصمیمات معماری که در فاز طراحی گرفته شده. این سند مرجع اصلی پروژه است.

---

## ۱. هدف پروژه

تبدیل اندیکاتور Pine Script (`Mutanabby_AI | Fresh Algo V24`) به یک سیستم کامل سیگنال‌دهی خودکار برای
تایم‌فریم ۱ ساعته، شامل: بک‌تست، مدل یادگیری ماشین اختصاصی هر ارز، بهینه‌سازی خودکار پارامترها،
اجرای ساعتی از طریق GitHub Actions، ارسال سیگنال به تلگرام و ذخیره‌سازی در Supabase.

**واچ‌لیست پیش‌فرض (۱۰ ارز):** BTC, ETH, SOL, BNB, XRP, ADA, DOGE, AVAX, LINK, TON
(قابل تغییر در `config/watchlist.yaml`)

---

## ۲. لایه‌ی دیتا

### ۲.۱ منابع
| منبع | نقش | محدودیت |
|---|---|---|
| **CoinEx** (`ccxt`) | دیتای زنده (سیگنال ساعتی) + بخش اخیر بک‌تست | تاریخچه محدود |
| **Yahoo Finance** (`yfinance`) | بک‌تست بلندمدت (۲ سال) | فقط بخش تاریخی، نه لایو |

### ۲.۲ مشکل ناسازگاری منابع و راه‌حل (Calibration)

قیمت Yahoo (تجمیعی/ایندکسی) با قیمت واقعی CoinEx یکی نیست. ریسک: مدل روی رفتار قیمتی Yahoo آموزش
ببیند ولی در Live روی CoinEx اجرا شود → انحراف عملکرد واقعی از بک‌تست.

**راه‌حل پیاده‌سازی‌شده (`data/calibration.py`):**
1. بازه‌ی هم‌پوشان بین دو منبع (معمولاً ۶ ماه اخیر) پیدا می‌شود.
2. ضریب تعدیل (calibration ratio) بر اساس میانگین اختلاف درصدی close-to-close محاسبه می‌شود.
3. بخش تاریخی Yahoo با این ضریب نرمال‌سازی می‌شود.
4. ستون `source` در تمام دیتافریم‌ها نگه داشته می‌شود — در گزارش بک‌تست شفاف مشخص است کدام بخش
   از کدام منبع آمده.
5. **قاعده‌ی طلایی:** مدل نهایی که در Live استفاده می‌شود، فقط با داده‌ی CoinEx (حتی اگر کوتاه‌تر
   است) fine-tune/ری‌ترین می‌شود. داده‌ی Yahoo صرفاً برای اعتبارسنجی کلی منطق استراتژی و آموزش اولیه
   استفاده می‌شود، نه به‌عنوان منبع نهایی حقیقت برای تصمیم‌های Live.

### ۲.۳ کش و ذخیره‌سازی
تمام کندل‌های دریافتی (هر دو منبع) در جدول `ohlcv_cache` در Supabase ذخیره می‌شوند تا از
درخواست تکراری به API جلوگیری شود و برای بازتولید (reproducibility) بک‌تست‌ها در دسترس باشند.

---

## ۳. تبدیل منطق Pine Script → Python

`features/indicators.py` معادل دقیق این بخش‌های کد اصلی را پیاده می‌کند:

- EMA150 / EMA250 (تشخیص روند کلی)
- Supertrend (`sensitivity`, `STuner`) — سیگنال اصلی crossover/crossunder
- Donchian Channel Trend (`maintrend`, دوره ۳۰)
- MACD(12,26,9)
- ADX/DMI(14) برای فیلتر Consolidation
- HMA(55)
- Wavetrend + Fractal Divergence (بخش Trap Detector / Reversal Dot)
- Volume Filter: `EMA(volume,15) − EMA(volume,20)` نرمال‌شده با `EMA(volume,25)`
- ATR-based Trailing Stop

**تصمیم مهم:** بخش MTF Dashboard (M5/M15/M30/1H/4H) از پیاده‌سازی حذف شده چون تمرکز پروژه فقط
روی تایم‌فریم ۱H است و نیازی به بهینه‌سازی چندتایم‌فریمی نیست.

منطق نهایی سیگنال (`bull`/`bear`) دقیقاً با همان شرایط crossover/crossunder + فیلترهای کد اصلی
در `strategy/core.py` پیاده‌سازی شده و **بین بک‌تست و اجرای زنده مشترک** است (یک‌بار نوشته، دو
جا import می‌شود) تا رفتار کاملاً یکسان تضمین شود.

---

## ۴. جلوگیری از نشت داده (Data Leakage)

- تمام اندیکاتورها فقط با اطلاعات `t` و قبل از آن محاسبه می‌شوند (بدون shift به آینده).
- برچسب آموزشی مدل ML با **Triple-Barrier Method** ساخته می‌شود: برای هر سیگنال، بررسی می‌شود
  کدام‌یک زودتر لمس می‌شود — TP یا SL — در یک بازه‌ی زمانی محدود. این نگاه‌به‌آینده *فقط* برای
  ساخت لیبل است، نه برای فیچرهای ورودی مدل.
- تقسیم train/test **زمانی (walk-forward)** است، هرگز رندوم.
- ری‌ترین ماهانه هم walk-forward است: فقط داده‌ی تا لحظه‌ی ری‌ترین دیده می‌شود.

---

## ۵. حلقه‌ی یادگیری تطبیقی (Adaptive Learning Loop) — هسته‌ی هوشمندی سیستم

### ۵.۱ فلسفه
سیستم نباید فقط یک‌بار روی داده‌ی تاریخی بهینه شود. باید از **نتیجه‌ی واقعی معاملات زنده‌ی خودش**
هم درس بگیرد و ماهانه پارامترها را بازبینی کند.

```
هر سیگنال زنده ← ذخیره در Supabase با وضعیت "pending"
هر اجرای ساعتی ← بررسی می‌کند آیا TP یا SL معاملات pending لمس شده
معامله بسته شد ← وضعیت + نتیجه‌ی واقعی ثبت می‌شود

ماهانه:
  ۱. تجمیع کل معاملات بسته‌شده (بک‌تست تاریخی + معاملات زنده‌ی جدید)
  ۲. ری‌ترین مدل ML با داده‌ی تجمیعی
  ۳. بهینه‌سازی مجدد پارامترهای ریسک و آستانه‌ی ML (بخش ۶)
  ۴. مقایسه‌ی نسخه‌ی جدید با نسخه‌ی فعلی → پذیرش فقط در صورت بهبود معنادار
  ۵. ثبت نسخه‌ی جدید در `param_history` + commit در گیت‌هاب
```

### ۵.۲ ترکیب وزن‌دار بک‌تست + داده‌ی زنده (Blending)
چون ماه‌های اول داده‌ی زنده کم است (آماره‌ی غیرقابل‌اعتماد)، وزن داده‌ی زنده به‌تدریج افزایش
می‌یابد:

```
param_final = w_backtest × param_from_history + w_live × param_from_recent_live
```
جدول وزن‌دهی نمونه (`ml/optimize.py`):

| ماه از شروع سیستم | وزن بک‌تست | وزن زنده |
|---|---|---|
| ۱ | ۰.۹ | ۰.۱ |
| ۳ | ۰.۷ | ۰.۳ |
| ۶ | ۰.۵ | ۰.۵ |
| ۱۲+ | ۰.۳ | ۰.۷ |

---

## ۶. تابع هدف بهینه‌سازی (بدون قید سخت روی تعداد معامله)

**تصمیم کلیدی:** به‌جای بازه‌ی ثابت "تعداد معامله در ماه"، از یک تابع هدف ترکیبی استفاده می‌شود
که خودش به‌طور طبیعی بین کیفیت و کمیت تعادل برقرار می‌کند:

```python
expectancy_per_trade = (win_rate * avg_win) - (loss_rate * avg_loss)
monthly_score = n_trades_per_month * expectancy_per_trade
adjusted_score = monthly_score * confidence_factor(n_trades)   # جریمه‌ی نمونه‌ی کم (Wilson-style)
```

- آستانه‌ی خیلی سفت → معاملات کم → حتی با کیفیت بالا، `monthly_score` به خاطر تعداد کم پایین می‌آید.
- آستانه‌ی خیلی شل → معاملات زیاد ولی نویزی → `expectancy_per_trade` نزدیک صفر/منفی می‌شود.
- بهینه دقیقاً جایی است که `adjusted_score` ماکسیمم شود.

---

## ۷. بهینه‌سازی پارامترها — فازبندی‌شده

### فاز ۱ (نسخه‌ی فعلی این ریپو)
موتور: **Optuna** (Bayesian Optimization) + **Walk-Forward Validation**

پارامترهای باز برای بهینه‌سازی:
- گروه ریسک: ضریب ATR استاپ‌لاس، نسبت‌های R:R برای TP1/2/3
- گروه ML: آستانه‌ی تأیید، هایپرپارامترهای LightGBM

پارامترهای **ثابت** (منطق هسته‌ی اندیکاتور، مطابق کد اصلی):
`sensitivity`, `STuner`, `MSTuner` و سایر پارامترهای تولید سیگنال bull/bear

محافظ‌های ضد Overfitting:
1. Walk-Forward: بهینه‌سازی روی بازه‌ی `t`، اعتبارسنجی روی `t+1` (دیده‌نشده)
2. بررسی پایداری پارامتر بین دوره‌های زمانی مختلف (نوسان شدید = نشانه‌ی overfit)
3. پذیرش نسخه‌ی جدید پارامتر فقط با بهبود آماری معنادار نسبت به نسخه‌ی فعلی

### فاز ۲ (آینده، مشروط)
اگر بعد از حداقل ۳-۴ ماه اجرای زنده، یک یا چند ارز عملکرد سیستماتیک ضعیف داشتند و علت آن «عدم
تناسب منطق سیگنال با آن ارز» تشخیص داده شد (نه ریسک یا ML)، پارامترهای هسته‌ی اندیکاتور
(`sensitivity`, `STuner`, `MSTuner`) هم فقط برای همان ارز(های) مشکل‌دار، با فضای جستجوی محدود
(±30٪ حول پیش‌فرض)، وارد بهینه‌سازی می‌شوند.

---

## ۸. ساختار ریپو

```
mutanabby-signal-system/
├── .github/workflows/
│   ├── hourly_signal.yml       # کرون هر ساعت
│   └── monthly_retrain.yml     # کرون ماهانه
├── config/
│   ├── watchlist.yaml
│   └── params_default.yaml     # مقادیر پیش‌فرض کد اصلی (baseline)
├── data/
│   ├── coinex_client.py
│   ├── yahoo_client.py
│   └── calibration.py
├── features/
│   └── indicators.py           # معادل دقیق منطق Pine Script
├── strategy/
│   └── core.py                 # منطق مشترک سیگنال (بک‌تست + لایو)
├── backtest/
│   ├── engine.py
│   └── report_generator.py     # خروجی HTML/Markdown در reports/
├── ml/
│   ├── features.py             # فیچرهای ورودی مدل
│   ├── labeling.py              # Triple-Barrier Method
│   ├── train.py
│   ├── predict.py
│   └── optimize.py             # Optuna + Walk-Forward + Blending
├── notify/
│   └── telegram_bot.py
├── storage/
│   └── supabase_client.py
├── jobs/
│   ├── hourly_signal.py        # اسکریپت اجرای ساعتی
│   └── monthly_retrain.py      # اسکریپت اجرای ماهانه
├── reports/                    # خروجی بک‌تست‌ها (commit می‌شود)
├── tests/
├── requirements.txt
├── .env.example
└── README.md
```

---

## ۹. طرح جداول Supabase

```sql
-- کش کندل‌ها
ohlcv_cache (
  id, symbol, timeframe, timestamp, open, high, low, close, volume, source
)

-- سیگنال‌های صادرشده و نتیجه‌شان
signals (
  id, symbol, timestamp, direction, entry, stop_loss, tp1, tp2, tp3,
  ml_confidence, status,        -- pending / tp1_hit / tp2_hit / tp3_hit / sl_hit / expired
  closed_at, pnl_pct, sent_to_telegram, params_version
)

-- تاریخچه‌ی مدل‌های ML هر ارز
model_registry (
  id, symbol, version, trained_at, metrics_json, file_path, is_active
)

-- تاریخچه‌ی پارامترهای بهینه‌شده (ریسک + آستانه ML) هر ارز
param_history (
  id, symbol, version, effective_from, atr_mult, tp1_r, tp2_r, tp3_r,
  ml_threshold, adjusted_score, backtest_weight, live_weight, accepted, notes
)

-- نتایج اجرای بک‌تست
backtest_runs (
  id, symbol, date_range_start, date_range_end, metrics_json, report_path
)
```

---

## ۱۰. اجرای خودکار (GitHub Actions)

### `hourly_signal.yml`
```yaml
on:
  schedule:
    - cron: '5 * * * *'   # ۵ دقیقه بعد از بسته‌شدن هر کندل ۱ساعته
```
مراحل: fetch کندل جدید از CoinEx → محاسبه فیچر (`features/indicators.py`) →
اجرای `strategy/core.py` → فیلتر ML (`ml/predict.py`) → اگر تأیید شد: ارسال تلگرام +
ذخیره در Supabase → به‌روزرسانی وضعیت معاملات pending قبلی (چک TP/SL)

### `monthly_retrain.yml`
```yaml
on:
  schedule:
    - cron: '0 3 1 * *'   # اول هر ماه، ساعت ۰۳:۰۰ UTC
```
مراحل: دریافت داده‌ی جدید (هر دو منبع) → ری‌ترین ML → بهینه‌سازی Optuna (ریسک+آستانه) →
walk-forward validation → مقایسه با نسخه‌ی فعلی → commit مدل/پارامتر جدید + گزارش تغییرات

---

## ۱۱. تکنولوژی‌ها

| بخش | ابزار |
|---|---|
| زبان | Python 3.11 |
| دیتا | pandas, numpy, ccxt (CoinEx), yfinance |
| ML | lightgbm, scikit-learn, optuna |
| بک‌تست/گزارش | plotly (نمودار تعاملی HTML) |
| تلگرام | python-telegram-bot |
| دیتابیس | supabase-py |
| اجرا | GitHub Actions (cron) |

---

## ۱۲. نقشه‌ی راه (Roadmap)

- [x] فاز طراحی و تصمیمات معماری
- [ ] اسکلت ریپو + پیاده‌سازی `features/indicators.py` و `strategy/core.py`
- [ ] پیاده‌سازی لایه‌ی دیتا + calibration
- [ ] موتور بک‌تست + گزارش‌گیری
- [ ] Labeling (Triple-Barrier) + آموزش اولیه‌ی مدل ML هر ارز
- [ ] بهینه‌سازی Optuna (فاز ۱: ریسک + ML)
- [ ] اتصال تلگرام + Supabase
- [ ] راه‌اندازی GitHub Actions (ساعتی + ماهانه)
- [ ] دوره‌ی مشاهده‌ی زنده (۳-۴ ماه) قبل از تصمیم درباره‌ی فاز ۲
