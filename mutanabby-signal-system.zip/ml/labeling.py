"""
Triple-Barrier Labeling — مطابق architecture.md بخش ۴.
برای هر سیگنال rule-based، برچسب بر اساس این‌که TP یا SL زودتر لمس شود ساخته می‌شود.
این تنها جایی در کل پروژه است که مجاز به "نگاه به آینده" هستیم — و فقط برای ساخت لیبل،
نه برای فیچرهای ورودی مدل (که باید تا لحظه‌ی سیگنال محدود بمانند).
"""
from __future__ import annotations
import pandas as pd
from backtest.engine import _simulate_exit
from strategy.core import Signal


def label_signal(df: pd.DataFrame, entry_idx: int, sig: Signal) -> int:
    """
    خروجی: 1 = سیگنال موفق (به TP1 یا بالاتر رسید قبل از SL)
           0 = سیگنال ناموفق (SL خورد قبل از هر TP)
    """
    trade = _simulate_exit(df, entry_idx, sig)
    return 1 if trade.outcome in ("tp1", "tp2", "tp3") else 0


def build_labeled_dataset(df_with_signals: pd.DataFrame, symbol: str, risk_params: dict) -> pd.DataFrame:
    """
    df_with_signals: خروجی strategy.core.generate_raw_signals (شامل ستون‌های bull/bear)
    خروجی: دیتافریم فقط شامل ردیف‌هایی که سیگنال صادر شده، با ستون‌های فیچر + label
    """
    from strategy.core import build_signal
    from ml.features import extract_feature_row

    rows = []
    for i in range(len(df_with_signals)):
        row = df_with_signals.iloc[i]
        if not (row.get("bull") or row.get("bear")):
            continue
        sig = build_signal(df_with_signals, i, symbol, risk_params)
        if sig is None:
            continue
        label = label_signal(df_with_signals, i, sig)
        features = extract_feature_row(df_with_signals, i)
        features["label"] = label
        features["timestamp"] = df_with_signals.index[i]
        rows.append(features)

    return pd.DataFrame(rows)
